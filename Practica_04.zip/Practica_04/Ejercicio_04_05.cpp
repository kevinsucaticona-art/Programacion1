// Materia: Programación I, Paralelo 4 
// Autor: Kevin Yosner Sucaticona Rodriguez 
// Fecha creación: 13/04/2026
#include <iostream>
using namespace std;

int main() {
    system("cls");

    int N, M;
    cout << "Ingrese N: ";
    cin >> N;
    cout << "Ingrese M: ";
    cin >> M;

    int A[100][100], B[100][100], C[100][100];

   
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            C[i][j] = 0;
        }
    }

   
    cout << "Ingrese matriz A:\n";
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            cin >> A[i][j];
        }
    }

   
    cout << "Ingrese matriz B:\n";
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            cin >> B[i][j];
        }
    }

    
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            for (int k = 0; k < M; k++) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }

   
    cout << "\nMatriz resultado C:\n";
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            cout << C[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}