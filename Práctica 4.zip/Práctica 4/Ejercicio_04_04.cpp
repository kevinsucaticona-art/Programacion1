// Materia: Programación I, Paralelo 4
// Autor: Kevin Yosner Sucaticona Rodriguez
// Carnet: 14418162
// Carrera: Ingeniería Biomédica
// Fecha creación: 04/03/2026


#include <iostream>
using namespace std;

void Moneda(double bs, double oficial, double paralelo)
{
    cout << "Cambio oficial: " << bs / oficial << " USD";
    cout << "\nCambio paralelo: " << bs / paralelo << " USD";
}

int main()
{
    double monto = 0;
    double oficial = 0;
    double paralelo = 0;
    cout << "Monto en Bolivianos: ";
    cin >> monto;
    cout << "Tipo de cambio oficial: ";
    cin >> oficial;
    cout << "Tipo de cambio paralelo: ";
    cin >> paralelo;
    Moneda(monto, oficial, paralelo);
    return 0;
}