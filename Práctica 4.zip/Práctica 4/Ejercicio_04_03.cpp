// Materia: Programación I, Paralelo 4
// Autor: Kevin Yosner Sucaticona Rodriguez
// Carnet: 14418162
// Carrera: Ingeniería Biomédica
// Fecha creación: 04/03/2026

#include <iostream>
using namespace std;

const double PI = 3.14159; 

double Volumen(double radio, double altura)
{
    return PI * radio * radio * altura;
}

int main() {
    double radio = 0;
    double altura = 0;
    cout << "Ingrese el radio: ";
    cin >> radio;
    cout << "Ingrese la altura: ";
    cin >> altura;
    cout << "El volumen del cilindro es: " << Volumen(radio, altura);
    return 0;
}