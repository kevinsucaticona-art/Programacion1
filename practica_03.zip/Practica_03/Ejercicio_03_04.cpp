// Materia: Programación I, Paralelo 4
// Autor: Kevin Yosner Sucaticona Rodriguez
// Carnet: 14418162
// Carrera del estudiante: Ingeniería Biomédica 
// Fecha creación: 27/02/2026
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()

{
system("cls");
  
int numero=0;
int sumatoria_total=0;
double promedio=0;
int mayor_valor_generado=0;
int menor_valor_generado=1001;
 
cout<<"Ingrese un numero aleatorio entre 1 y 1000: " ;
cin >>numero;

srand(time(NULL));

for (int i = 0; i < numero; i++) 
    {
        int numero_aleatorio = (rand() % 1000) + 1;
        sumatoria_total += numero_aleatorio;   //el += es acumulativo
        if (numero_aleatorio > mayor_valor_generado)
        {
            mayor_valor_generado = numero_aleatorio;
        }
        if (numero_aleatorio < menor_valor_generado)
        {
            menor_valor_generado = numero_aleatorio;
        }
    }
 promedio = sumatoria_total / (double)numero;
 
 cout<<"la sumatoria total de los numeros es:" <<sumatoria_total<<endl;
 cout<<"El promedio es :" <<promedio<<endl;
 cout<<"El mayor numero generado es :" <<mayor_valor_generado<<endl;
 cout<<"El menor numero generado es :" <<menor_valor_generado<<endl;
return 0;
}