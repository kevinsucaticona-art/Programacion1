// Materia: Programación I, Paralelo 4
// Autor: Kevin Yosner Sucaticona Rodriguez
// Carnet: 14418162
// Carrera del estudiante: Ingeniería Biomédica
// Fecha creación: 27/02/2026
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int esPrimo(int num)
{
    if (num <= 1)
        return 0;
    for (int i = 2; i * i <= num; i++)
    {
        if (num % i == 0)
            return 0;
    }
    return 1;
}

int main()
{
    int N;
    cout << "Introduce el valor de N (número de números aleatorios a generar): ";
    cin >> N;

    srand(time(0));

    int cantidadPrimos = 0;

    cout << "Números aleatorios generados:" << endl;

    for (int i = 0; i < N; i++)
    {
        int numero = rand() % 10000 + 1;
        cout << numero << " ";

        if (esPrimo(numero))
        {
            cantidadPrimos++;
        }
    }

    cout << endl;
    cout << "Cantidad de números primos: " << cantidadPrimos << endl;

    return 0;
}