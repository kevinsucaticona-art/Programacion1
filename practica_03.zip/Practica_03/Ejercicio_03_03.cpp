// Materia: Programación I, Paralelo 4
// Autor: Kevin Yosner Sucaticona Rodriguez
// Carnet: 14418162
// Carrera del estudiante: Ingeniería Biomédica 
// Fecha creación: 27/02/2026
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
    system("cls");
    int numero=0;
    int factorial=1;
    int i =1;
    cout<<"Ingrese un numero del 1 al 10: ";
    cin>> numero;
    for (int i =1 ; i<= numero;i++ )
{
    factorial=factorial*i;
}
cout<<"El resultado Factorial es  : "<<factorial<<endl;
   

        
    return 0;
}