#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
    system("cls");
    int numero=0;
    int vecespares=0;
    double frecuencia=0;
    cout<< "ingrese la cantidad de veces que se lanzara el dado: " ;
    cin>> numero;
    srand(time(NULL));
    for (int i = 0; i < numero; i++) 
    {
        int dado = (rand() % 6)+ 1;
        if ( dado % 2 == 0)
        {
            vecespares++;
        }
            
    }
    if (numero>0)
    {
        frecuencia= (double)vecespares / numero;

    }
    cout<< "la frecuncia de veces pares de un dado es:" << frecuencia ;
return 0 ;
}