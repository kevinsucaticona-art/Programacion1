
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
    system("cls");
    int numero = 0;
    int cara = 0;
    int cruz= 0;
    double porcentajeCaras=0;
    double porcentajeCruces=0;

    cout << "ingrese la cantidad de veces que se lanzara la moneda: ";
    cin >> numero;

    srand(time(NULL));

    for (int i = 0; i < numero; i++) 
    {
        int lanzamiento = (rand() % 2) + 1;
        if (lanzamiento==1)
        {
             cara++; //tambien podemos usar cara= cara+1
        }
        else 
        {
             cruz++; //tambien podemos usar cruz= cruz+1
        }
    }

     porcentajeCaras=((double)cara/numero)*100;
     porcentajeCruces=((double)cruz/numero)*100;
 
    cout << "El porcentaje de caras es del  : " << porcentajeCaras  << endl;
    cout << "El porcentaje de cruces es del : " << porcentajeCruces  << endl;



    return 0;
}