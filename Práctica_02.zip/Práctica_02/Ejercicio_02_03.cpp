// Materia: Programación I, Paralelo 4
// Autor: Kevin Yosner Sucaticona Rodríguez 
// Carnet: 14418162
// Carrera del estudiante: Ingeniería Biomédica 
// Fecha creación: 23/02/2026

#include <iostream>
using namespace std;

int main() 
{
    int n = 0 ; 
    int suma = 0;
    cout << "Digite el número y se sumará : ";
    cin >> n;

    for (int i = 1; i <= n; i++) 
    {
        suma = suma + i;
    }
    cout << "Total: " << suma;
    return 0;
}