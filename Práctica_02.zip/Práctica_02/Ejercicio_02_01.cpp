// Materia: Programación I, Paralelo 4
// Autor: keviYosner Sucaticona Rodríguez 
// Carnet:  14418162
// Carrera del estudiante: Ingeniería Biomédica 
// Fecha creación: 23/02/2026

#include <iostream>
using namespace std;

int main() 
{
    int numero = 0;
    cout << "Ingresar numero del 1 al 10: ";
    cin >> numero;
    for (int i = 1; i <= 10; i++) 
    {
        cout << numero << " x " << i << " = " << numero * i << endl;
    }
    return 0;
}