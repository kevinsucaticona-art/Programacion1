// Materia: Programación I, Paralelo 4
// Autor: Kevin Yosner Sucaticona Rodríguez 
// Carnet: 14418162
// Carrera del estudiante: Ingeniería Biomédica
// Fecha creación: 23/02/2026

#include <iostream>
using namespace std;

int main() 
{
    int n;
    long long factorial = 0; 
    cout << "Ingresa un numero: ";
    cin >> n;

    for (int i = 1; i <= n; i++) 
    {
        long long resultado_factorial = 1;
        
        for (int j = 1; j <= i; j++) 
        {
            resultado_factorial = resultado_factorial * j;
        }
        factorial = factorial + resultado_factorial;
    }
    cout << "Total: " << factorial;
    return 0;
}