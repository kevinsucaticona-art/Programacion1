// Materia: Programación I, Paralelo 4
// Autor: Kevin yosner Sucaticona Rodriguez
// Carnet: 14418162
// Carrera del estudiante: Ingeniería Biomédica 
// Fecha creación: 23/02/2026


#include <iostream>
using namespace std;

int main() 
{
    int numero;
    int total ;
    int pares ;
    int impares;
    int primos ;
    cout << "Escribe numeros del 0 a 100 al poner 0 termina el programa:";
    do 
    {
        cin >> numero;
        if (n != 0) 
        {
            total = total + n;
            if (n % 2 == 0) 
            {
                pares = pares + n;
            } 
            else 
            {
                impares = impares + n;
            }
            int divisores = 0;
            for (int i = 1; i <= n; i++) 
            {
                if (n % i == 0) 
                {
                    divisores = divisores + 1;
                }
            }
            if (divisores == 2) 
            {
                primos = primos + n;
            }
        }
    } 
    while (n != 0);

    cout << "Suma total: " << total;
    cout << "\nSuma de pares: " << pares;
    cout << "\nSuma de impares: " << impares;
    cout << "\nSuma de primos: " << primos;

    return 0;
}