// Materia: Programación I, Paralelo 4
// Autor: Kevin Yosner Sucaticona Rodriguez 
// Carnet: 14418162
// Carrera: Ingeniería Biomédica
// Fecha creación: 06/03/2026

#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

double Bonificacion(double horas, double tarifa)
{
    if (horas > 8)
    {
        return (horas - 8) * (tarifa * 0.5);
    }
    return 0;
}

int main()
{
    srand(time(0));
    double tarifa;
    cout << "Ingrese la tarifa por hora: ";
    cin >> tarifa;

    double horas = 1 + rand() % (13 - 1);

    double bonifica = Bonificacion(horas, tarifa);
    double salarioFinal = (horas * tarifa) + bonifica;

    cout << "Horas trabajadas (generadas): " << horas;
    cout << "\nSalario total: " << salarioFinal << " Bs.";
    cout << "\nSalario bonificacion: " << bonifica << " Bs.";

    return 0;
}