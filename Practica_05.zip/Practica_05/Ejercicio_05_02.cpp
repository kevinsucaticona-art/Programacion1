// Materia: Programación I, Paralelo 4
// Autor: Kevin Yosner Sucaticona Rodriguez 
// Carnet: 14418162
// Carrera: Ingeniería Biomédica
// Fecha creación: 06/03/2026

#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

double Comision(double ventas) 
{
    return ventas * 0.10;
}

int main() 
{
    srand(time(0));
    int n;
    cout << "Ingrese el numero de vendedoras: ";
    cin >> n;

    for(int i = 1; i <= n; i++) 
    {
        // Generamos datos aleatorios para cada vendedora
        double basico = 2250 + rand() % (5001 - 2250);
        double ventas = 1000 + rand() % (10001 - 1000);

        double comision = Comision(ventas);
        
        cout << "\nVendedora " << i << ":";
        cout << "\nSueldo basico generado: " << basico << " Bs.";
        cout << "\nVentas generadas: " << ventas << " Bs.";
        cout << "\nComision extra (10%): " << comision << " Bs.";
        cout << "\nSueldo Total: " << basico + comision << " Bs.";
    }
    return 0;
}