//Ejercicio 2 PIXELES
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int aleatorio(int inferior, int superior)
{
    int numero;
    numero = rand() % (superior - inferior + 1) + inferior;
    return numero;
}

int main()
{
    srand(time(NULL));

    int N;
    cout << "Cantidad de pixeles: ";
    cin >> N;

    int rangos[26] = {0};

    for(int i = 0; i < N; i++)
    {
        int pixel = aleatorio(0, 255);

        cout << pixel << " ";

        if(pixel >= 250)
            rangos[25]++;
        else
            rangos[pixel / 10]++;
    }

    cout << "\n\nPixeles por rango:\n";

    for(int i = 0; i < 25; i++)
    {
        cout << i * 10 << "-" << i * 10 + 9
             << ": " << rangos[i] << endl;
    }

    cout << "250-255: " << rangos[25] << endl;

    return 0;
}