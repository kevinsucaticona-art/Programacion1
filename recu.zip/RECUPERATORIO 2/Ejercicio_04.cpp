// Ejercicio 4 MATRIZ N*N
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

// Función de aleatorios con límites
int aleatorio(int inferior, int superior)
{
    return rand() % (superior - inferior + 1) + inferior;
}

int main()
{
    srand(time(NULL));

    int matriz[100][100];
    int N;

    cout << "Ingrese el tamano de la matriz N: ";
    cin >> N;

    // Llenar matriz con aleatorios de 0 a 100
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            matriz[i][j] = aleatorio(0, 100);
        }
    }

    // Mostrar matriz
    cout << "\nMATRIZ\n";
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            cout << matriz[i][j] << "\t";
        }
        cout << endl;
    }

    // Suma de la primera columna
    int sumaColumna = 0;
    for (int i = 0; i < N; i++)
    {
        sumaColumna += matriz[i][0];
    }

    // Producto de la primera fila
    long long productoFila = 1;
    for (int j = 0; j < N; j++)
    {
        productoFila *= matriz[0][j];
    }

    // Menor valor y posición
    int menor = matriz[0][0];
    int filaMenor = 0;
    int columnaMenor = 0;

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            if (matriz[i][j] < menor)
            {
                menor = matriz[i][j];
                filaMenor = i;
                columnaMenor = j;
            }
        }
    }

    cout << "\nSuma de la primera columna: " << sumaColumna;
    cout << "\nProducto de la primera fila: " << productoFila;
    cout << "\nMenor valor: " << menor;
    cout << "\nPosicion: (" << filaMenor << "," << columnaMenor << ")\n";

    return 0;
}