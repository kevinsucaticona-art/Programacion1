// Ejercicio 3 PALINDROMOS
#include <iostream>
#include <string>

using namespace std;

bool esPalindromo(string texto)
{
    string limpio = "";

    // Guardar solo letras minúsculas
    for(int i = 0; i < texto.length(); i++)
    {
        if(texto[i] >= 'A' && texto[i] <= 'Z')
        {
            limpio += texto[i] + 32; // convertir a minúscula
        }
        else if(texto[i] >= 'a' && texto[i] <= 'z')
        {
            limpio += texto[i];
        }
    }

    int i = 0;
    int j = limpio.length() - 1;

    while(i < j)
    {
        if(limpio[i] != limpio[j])
        {
            return false;
        }

        i++;
        j--;
    }

    return true;
}

int main()
{
    string texto;

    cout << "Ingrese una frase: ";
    getline(cin, texto);

    if(esPalindromo(texto))
        cout << "Es palindromo";
    else
        cout << "No es palindromo";

    return 0;
}