// Problema 7 PACIENTES
#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>

using namespace std;

// PROTOTIPOS
int aleatorio(int inferior, int superior);
void cargarPacientes(vector<string> &pacientes);
void cargarTemperaturas(int monitoreo[5][24]);
void mostrarTemperaturas(vector<string> pacientes, int monitoreo[5][24]);
void VerificarAlertas(vector<string> pacientes, int monitoreo[5][24], int umbral);

int main()
{
    srand(time(NULL));

    vector<string> pacientes(5);
    int monitoreo[5][24];
    int umbral;

    cargarPacientes(pacientes);
    cargarTemperaturas(monitoreo);

    cout << "Ingrese el umbral de temperatura: ";
    cin >> umbral;

    mostrarTemperaturas(pacientes, monitoreo);

    VerificarAlertas(pacientes, monitoreo, umbral);

    return 0;
}

// FUNCIONES

int aleatorio(int inferior, int superior)
{
    return rand() % (superior - inferior + 1) + inferior;
}

void cargarPacientes(vector<string> &pacientes)
{
    pacientes[0] = "Ana Torroja";
    pacientes[1] = "Juan Luna";
    pacientes[2] = "Sergio Murillo";
    pacientes[3] = "Liliana Espinoza";
    pacientes[4] = "Mercedes Lima";
}

void cargarTemperaturas(int monitoreo[5][24])
{
    for (int i = 0; i < 5; i++)
    {
        for (int j = 0; j < 24; j++)
        {
            monitoreo[i][j] = aleatorio(20, 40);
        }
    }
}

void mostrarTemperaturas(vector<string> pacientes, int monitoreo[5][24])
{
    cout << "\nREGISTRO DE TEMPERATURAS\n\n";

    for (int i = 0; i < 5; i++)
    {
        cout << pacientes[i] << ": ";

        for (int j = 0; j < 24; j++)
        {
            cout << monitoreo[i][j] << " ";
        }

        cout << endl;
    }
}

void VerificarAlertas(vector<string> pacientes, int monitoreo[5][24], int umbral)
{
    cout << "\nPACIENTES CON ALERTA\n\n";

    for (int i = 0; i < 5; i++)
    {
        int contador = 0;

        for (int j = 0; j < 24; j++)
        {
            if (monitoreo[i][j] > umbral)
            {
                contador++;
            }
        }

        if (contador > 3)
        {
            cout << pacientes[i]
                 << " supero el umbral "
                 << contador
                 << " veces." << endl;
        }
    }
}