//EJERCICIO 1 NOMBRES IGUALES 
#include <iostream>
#include <vector>
#include <string>

using namespace std;

int main() {
    int n1, n2;

    cout << "Cantidad de clientes de la empresa 1: ";
    cin >> n1;

    vector<string> empresa1(n1);

    cout << "Ingrese los nombres de los clientes de la empresa 1:" << endl;
    for (int i = 0; i < n1; i++) {
        cin >> empresa1[i];
    }

    cout << "\nCantidad de clientes de la empresa 2: ";
    cin >> n2;

    vector<string> empresa2(n2);

    cout << "Ingrese los nombres de los clientes de la empresa 2:" << endl;
    for (int i = 0; i < n2; i++) {
        cin >> empresa2[i];
    }

    cout << "\nClientes en comun:" << endl;

    int contador = 0;

    for (int i = 0; i < n1; i++) {
        for (int j = 0; j < n2; j++) {
            if (empresa1[i] == empresa2[j]) {
                cout << empresa1[i] << endl;
                contador++;
                break;
            }
        }
    }

    cout << "\nCantidad de clientes repetidos: " << contador << endl;

    return 0;
}