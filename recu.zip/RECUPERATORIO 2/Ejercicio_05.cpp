//Ejercicio 5 VENTAS EN SUCURSAL
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

const int FILAS = 4;
const int COLUMNAS = 7;


int aleatorio(int inferior, int superior)
{
    int numero;
    numero = rand() % (superior - inferior + 1) + inferior;
    return numero;
}


void MostrarMatriz(int ventas[FILAS][COLUMNAS])
{
    cout << "\nMATRIZ DE VENTAS\n\n";

    for(int i = 0; i < FILAS; i++)
    {
        for(int j = 0; j < COLUMNAS; j++)
        {
            cout << ventas[i][j] << "\t";
        }
        cout << endl;
    }
}


void VentasPorSucursal(int ventas[FILAS][COLUMNAS])
{
    cout << "\nVENTAS POR SUCURSAL\n";

    for(int i = 0; i < FILAS; i++)
    {
        int suma = 0;

        for(int j = 0; j < COLUMNAS; j++)
        {
            suma += ventas[i][j];
        }

        cout << "Sucursal " << i + 1
             << ": " << suma << endl;
    }
}


void VentasPorDia(int ventas[FILAS][COLUMNAS])
{
    cout << "\nVENTAS POR DIA\n";

    for(int j = 0; j < COLUMNAS; j++)
    {
        int suma = 0;

        for(int i = 0; i < FILAS; i++)
        {
            suma += ventas[i][j];
        }

        cout << "Dia " << j + 1
             << ": " << suma << endl;
    }
}

int main()
{
    srand(time(NULL));

    int ventas[FILAS][COLUMNAS];

    // Llenar matriz con ventas aleatorias
    for(int i = 0; i < FILAS; i++)
    {
        for(int j = 0; j < COLUMNAS; j++)
        {
            ventas[i][j] = aleatorio(100, 1000);
        }
    }

    MostrarMatriz(ventas);
    VentasPorSucursal(ventas);
    VentasPorDia(ventas);

    return 0;
}