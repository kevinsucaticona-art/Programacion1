//Ejercicio 6 NOTAS DE ESTUDIANTES
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

const int ESTUDIANTES = 20;
const int PARCIALES = 3;

// PROTOTIPOS
int aleatorio(int inferior, int superior);
void cargarNotas(float notas[ESTUDIANTES][PARCIALES]);
void mostrarNotas(float notas[ESTUDIANTES][PARCIALES]);
void promedioEstudiantes(float notas[ESTUDIANTES][PARCIALES], float promedios[ESTUDIANTES]);
int mejorEstudiante(float promedios[ESTUDIANTES]);
float promedioGeneral(float promedios[ESTUDIANTES]);

int main()
{
    srand(time(NULL));

    float notas[ESTUDIANTES][PARCIALES];
    float promedios[ESTUDIANTES];

    cargarNotas(notas);
    mostrarNotas(notas);

    promedioEstudiantes(notas, promedios);

    cout << "\nPROMEDIOS FINALES\n";

    for(int i = 0; i < ESTUDIANTES; i++)
    {
        cout << "Estudiante " << i + 1
             << ": " << promedios[i] << endl;
    }

    int mejor = mejorEstudiante(promedios);

    cout << "\nMejor estudiante: " << mejor + 1 << endl;
    cout << "Promedio del mejor estudiante: "
         << promedios[mejor] << endl;

    cout << "Promedio general del grupo: "
         << promedioGeneral(promedios) << endl;

    return 0;
}

// FUNCIONES

int aleatorio(int inferior, int superior)
{
    int numero;
    numero = rand() % (superior - inferior + 1) + inferior;
    return numero;
}

void cargarNotas(float notas[ESTUDIANTES][PARCIALES])
{
    for(int i = 0; i < ESTUDIANTES; i++)
    {
        for(int j = 0; j < PARCIALES; j++)
        {
            notas[i][j] = aleatorio(0, 100);
        }
    }
}

void mostrarNotas(float notas[ESTUDIANTES][PARCIALES])
{
    cout << "\nNOTAS DE LOS ESTUDIANTES\n\n";

    for(int i = 0; i < ESTUDIANTES; i++)
    {
        cout << "Estudiante " << i + 1 << ": ";

        for(int j = 0; j < PARCIALES; j++)
        {
            cout << notas[i][j] << " ";
        }

        cout << endl;
    }
}

void promedioEstudiantes(float notas[ESTUDIANTES][PARCIALES],
                         float promedios[ESTUDIANTES])
{
    for(int i = 0; i < ESTUDIANTES; i++)
    {
        float suma = 0;

        for(int j = 0; j < PARCIALES; j++)
        {
            suma += notas[i][j];
        }

        promedios[i] = suma / PARCIALES;
    }
}

int mejorEstudiante(float promedios[ESTUDIANTES])
{
    int indice = 0;

    for(int i = 1; i < ESTUDIANTES; i++)
    {
        if(promedios[i] > promedios[indice])
        {
            indice = i;
        }
    }

    return indice;
}

float promedioGeneral(float promedios[ESTUDIANTES])
{
    float suma = 0;

    for(int i = 0; i < ESTUDIANTES; i++)
    {
        suma += promedios[i];
    }

    return suma / ESTUDIANTES;
}