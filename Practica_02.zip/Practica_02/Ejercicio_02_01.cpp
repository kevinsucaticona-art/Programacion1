// Materia: Programación I, Paralelo 4 
// Autor:Kevin Yosner Sucaticona Rodriguez 
// Fecha creación: 27/03/2026 
#include <iostream>
#include <vector>

using namespace std;

int GenerarAleatorio(int limInf, int limSup);
int main()
{
    system("cls");
    int n;
    int m;
    int y;
    int x;
    int z;
    cout << "ingrese el tamano del vector , para voltajes:";
    cin >> n;
    cout << "ingrese el tamano del vector , para temperaturas:";
    cin >> m;
    cout << "ingrese el tamano del vector , para anios:";
    cin >> y;
    cout << "ingrese el tamano del vector , para velocidades:";
    cin >> x;
    cout << "ingrese el tamano del vector , para distancias:";
    cin >> z;
    double numero;
    double numero1;
    double numero2;
    int numero3;
    double numero4;
    vector<double> voltaje;
    vector<double> temperatura;
    vector<int> anios;
    vector<double> velocidad;
    vector<double> distancias;
    for (int i = 0; i < n; i++)
    {
        numero = GenerarAleatorio(20.00, 220.00);
        numero1 = GenerarAleatorio(0, 100);
        numero2 = GenerarAleatorio(10, 300);
        numero3 = GenerarAleatorio(1990, 2025);
        numero4 = GenerarAleatorio(1, 1000);
        voltaje.push_back(numero);
        temperatura.push_back(numero1);
        velocidad.push_back(numero2);
        anios.push_back(numero3);
        distancias.push_back(numero4);
    }
    cout << "\nVoltajes:\n";
    for (int i = 0; i < voltaje.size(); i++)
    {
        cout << voltaje[i] << " V" << " ";
    }
    cout << "\nTemperaturas\n";
    for (int i = 0; i < temperatura.size(); i++)
    {
        cout << temperatura[i] << " C" << " ";
    }
    cout << "\nAnios\n";
    for (int i = 0; i < anios.size(); i++)
    {
        cout << anios[i] << " anios" << " ";
    }
    cout << "\nVelocidades\n";
    for (int i = 0; i < velocidad.size(); i++)
    {
        cout << velocidad[i] << " m/s" << " ";
    }
    cout << "\nDistancias\n";
    for (int i = 0; i < distancias.size(); i++)
    {
        cout << distancias[i] << " m" << " ";
    }

    return 0;
}

int GenerarAleatorio(int limInf, int limSup)
{
    double aleatorio = 0;
    aleatorio = rand() % (limSup - limInf + 1) + limInf;
    return aleatorio;
}