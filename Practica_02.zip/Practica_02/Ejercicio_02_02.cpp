// Materia: Programación I, Paralelo 4 
// Autor:Kevin Yosner Sucaticona Rodriguez 
// Fecha creación: 27/03/2026 
#include <iostream>
#include <vector>

using namespace std;
int main()
{
    system("cls");
    vector<float> voltios(9);
    cout << "Ingrese 9 valores de Voltaje:" << endl;
    for (int i = 0; i < voltios.size(); i++)
    {
        cout << "Voltios" << i + 1 << " ";
        cin >> voltios[i];
    }
    for (int i = 0; i < voltios.size(); i++)
    {
        cout << voltios[i] << " ";
        if ((i + 1) % 3 == 0)
        {
            cout << endl;
        }
    }

    return 0;
}