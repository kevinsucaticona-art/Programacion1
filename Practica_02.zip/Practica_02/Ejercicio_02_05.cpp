// Materia: Programación I, Paralelo 4 
// Autor:Kevin Yosner Sucaticona Rodriguez 
// Fecha creación: 27/03/2026 
#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>

using namespace std;

int GenerarAleatorio(int limInf, int limSup);
int main()
{
    system("cls");
    srand(time(NULL));
    int n = 0;
    cout << "Ingrese el Tamano del Primer Vector:";
    cin >> n;
    int m = 0;
    cout << "Ingrese el Tamano del Segundo Vector:";
    cin >> m;
    int numero1;
    int numero2;
    vector<int> primero;
    vector<int> segundo;
    vector<int> combinado;
    cout << "\nVector 1:\n";
    for (int i = 0; i < n; i++)
    {
        numero1 = GenerarAleatorio(1, 100);
        primero.push_back(numero1);
    }
    for (int i = 0; i < primero.size(); i++)
    {
        cout << primero[i] << " ";
    }
    cout << "\nVector 2:\n";
    for (int i = 0; i < m; i++)
    {
        numero2 = GenerarAleatorio(1, 100);
        segundo.push_back(numero2);
    }
    for (int i = 0; i < segundo.size(); i++)
    {
        cout << segundo[i] << " ";
    }
    combinado.insert(combinado.end(), primero.begin(), primero.end()); // lineas para combinar 2 vectores en 1
    combinado.insert(combinado.end(), segundo.begin(), segundo.end()); // usa insert , end , begin
    cout << "\nVector Combinado:\n";
    for (int i = 0; i < combinado.size(); i++)
    {
        cout << combinado[i] << " ";
    }
    cout << endl;

    return 0;
}

int GenerarAleatorio(int limInf, int limSup)
{
    double aleatorio = 0;
    aleatorio = rand() % (limSup - limInf + 1) + limInf;
    return aleatorio;
}
