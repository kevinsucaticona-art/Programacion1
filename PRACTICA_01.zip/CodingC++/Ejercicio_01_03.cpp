#include <iostream>

using namespace std;

int main()
{
    
    int edad;
    char sexo;
    float altura;
    
    cout<<" Edad : "; 
    cin>> edad;
    cout<<" Sexo Masculino o Femenino : " ;
    cin>>  sexo;
    cout<< "Altura : " ;
    cin>>   altura ;
    
    cout<< " Su edad es de : " <<edad<<endl;
    cout<< " Su sexo es : " <<sexo<<endl;
    cout<< " Tiene altura de : " <<altura<<endl;

    return 0;
}
