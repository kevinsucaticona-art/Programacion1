// Mteria : Programación I , paralelo 4
// Autor: Kevin Yosner Sucaticona Rodriguez
// Carnet: 14418162
// Carrera del Estudiante: Ing Biomedica
// Fecha de creación 11/02/26

#include <iostream>

using namespace std;

int main()
{
    
    int nota_practica;
    int nota_teorica;
    int nota_participacion;
    int nota_total;
 
    
    cout<<" nota de practicas : "; 
    cin>> nota_practica;
    cout<<" nota de teoría  : " ;
    cin>>  nota_teorica;
    cout<< "nota de participacion : " ;
    cin>>   nota_participacion  ;
    
    nota_total=(nota_practica * 0.30)+(nota_teorica * 0.60)+(nota_participacion * 0.10);
    
    cout<<"La nota final del Estudiante es : " <<nota_total;

    return 0;
}
