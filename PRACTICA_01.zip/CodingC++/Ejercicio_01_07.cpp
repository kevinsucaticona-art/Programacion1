// Mteria : Programación I , paralelo 4
// Autor: Kevin Yosner Sucaticona Rodriguez
// Carnet: 14418162
// Carrera del Estudiante: Ing Biomedica
// Fecha de creación 11/02/26

#include <iostream>

using namespace std;

int main()
{
    
    int edad;
    
 
    
    cout<<" Escriba la edad  : "; 
    cin>> edad;
    
    if (edad>=18 && edad <=25){
       cout<<"esta entre 18 a 25 años: " ;}
       else {
       cout<<"no esta en el rango de 18 a 25 años: " ; }

    return 0;
}
