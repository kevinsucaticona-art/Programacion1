// Mteria : Programación I , paralelo 4
// Autor: Kevin Yosner Sucaticona Rodriguez
// Carnet: 14418162
// Carrera del Estudiante: Ing Biomedica
// Fecha de creación 11/02/26
#include <iostream>
using namespace std;

int main()
{
    int numero1;
    int numero2;
    int suma;
    int resta;
    int multiplicación;
    int división;
    cout<<"ingrese primer numero: " ;
    cin>> numero1;
    cout<<"ingrese segundo numero: " ;
    cin>> numero2;
    suma = numero1+numero2;
    resta = numero1-numero2;
    multiplicación = numero1*numero2;
    división= numero1/numero2;
    cout<< " suma: "  << suma ; 
    cout<< " resta: " << resta;
    cout<< " multipliacion : " << multiplicación;
    cout<< " división : " << división ;
    return 0;
}
