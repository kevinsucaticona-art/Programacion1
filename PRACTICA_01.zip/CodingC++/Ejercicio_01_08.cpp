// Mteria : Programación I , paralelo 4
// Autor: Kevin Yosner Sucaticona Rodriguez
// Carnet: 14418162
// Carrera del Estudiante: Ing Biomedica
// Fecha de creación 11/02/26

#include <iostream>

using namespace std;

int main()
{
    
    int numero_01;
    int numero_02;
    int numero_03;
    int numero_04;
    
 
    cout << " escriba 3 numeros  " ;
    cin >> numero_01>>numero_02>>numero_03;
    cout<< " escriba el cuarto numero: " ;
    cin >> numero_04;
    
    if (numero_04 == numero_01||numero_04 == numero_02||numero_04 == numero_03)
    {
    cout<< "los numeros coinciden" ;
    }
    else 
    {
    cout<< " los numero no coinciden" ;
    }
    return 0;
}
