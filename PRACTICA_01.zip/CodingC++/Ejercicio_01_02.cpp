#include <iostream>

using namespace std;

int main()
{
    int producto;
    int iva;
    
    //system("cls"); //limpiar pantalla
    cout << "producto";
    cin >> producto;
    iva = producto+(producto*0.13);
    cout<< "iva" << iva ;
    



    return 0;
}
