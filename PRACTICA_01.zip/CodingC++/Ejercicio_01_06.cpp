// Mteria : Programación I , paralelo 4
// Autor: Kevin Yosner Sucaticona Rodriguez
// Carnet: 14418162
// Carrera del Estudiante: Ing Biomedica
// Fecha de creación 11/02/26

#include <iostream>

using namespace std;

int main()
{
    
    int numero_entero;
    
 
    
    cout<<" Escriba el numero entero : "; 
    cin>> numero_entero;
    
    if (numero_entero % 2 == 0){
       cout<<"es un número par " ;}
       else {
       cout<<"es un número impar: " ; }

    return 0;
}
