// Mteria : Programación I , paralelo 4
// Autor: Kevin Yosner Sucaticona Rodriguez
// Carnet: 14418162
// Carrera del Estudiante: Ing Biomedica
// Fecha de creación 11/02/26

#include <iostream>

using namespace std;

int main()
{
    
    float cateto_A;
    float cateto_B;
    float hipotenusa;
 
    
    cout<<" Ingrese el valor del cateto_A : "; 
    cin>> cateto_A;
    cout<<" Ingrese el valor del cateto_B  : " ;
    cin>>  cateto_B;
    
    
    hipotenusa=sqrt(cateto_A*cateto_A+cateto_B*cateto_B);
    
    cout<<"La hipotenusa es  : " <<hipotenusa;

    return 0;
}
